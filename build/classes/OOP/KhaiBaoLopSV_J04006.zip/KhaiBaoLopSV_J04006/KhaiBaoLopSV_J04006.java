/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OOP.KhaiBaoLopSV_J04006;

import java.text.ParseException;
import java.util.Scanner;

/**
 *
 * @author nhokt
 */
public class KhaiBaoLopSV_J04006 {

    public static void main(String[] args) throws ParseException {
        Scanner sc = new Scanner(System.in);
        SinhVien sinhVien = new SinhVien("", sc.nextLine(), sc.nextLine(), sc.nextLine(), Float.parseFloat(sc.nextLine()));
        System.out.println(sinhVien);
    }
}
